var gateway = `ws://${window.location.hostname}/ws`;
var websocket;
// from RNT ebook 4.1 demo
window.addEventListener('load', onLoad);

/* 
NormOp works WITHOUT this code
DO NOT ACTIVATE  
corrected in v033b

Function to get current values on the webpage when it loads/refreshes
// from RNT ebook 4.1 demo
function getValues(){
 var xhr = new XMLHttpRequest();
 xhr.onreadystatechange = function() {
 if (this.readyState == 4 && this.status == 200) {
 var myObj = JSON.parse(this.responseText);
 console.log(myObj);
 document.getElementById("textFieldValue").innerHTML = myObj.textValue;
 document.getElementById("numberFieldValue").innerHTML = myObj.numberValue;
 }
 };
 xhr.open("GET", "/values", true);
 xh
*/


function onLoad(event) {
  initWebSocket();
}

function initWebSocket() {
  console.log('Trying to open a WebSocket connection...');
  websocket = new WebSocket(gateway);
  websocket.onopen    = onOpen;
  websocket.onclose   = onClose;
  websocket.onmessage = onMessage;
}

function onOpen(event) {
  console.log('Connection opened');
  websocket.send("states");
}

function onClose(event) {
  console.log('Connection closed');
  setTimeout(initWebSocket, 2000);
}

function onMessage(event) {
  var myObj = JSON.parse(event.data);
  console.log(myObj);
  for (i in myObj.gpios){
    var output = myObj.gpios[i].output;
    var state = myObj.gpios[i].state;
    console.log(output);
    console.log(state);
    if (state == "1"){
      document.getElementById(output).checked = true;
    }
    else{
      document.getElementById(output).checked = false;
    }
  }
  console.log(event.data);
}

// Send Requests to Control GPIOs
function toggleCheckbox (element) {
  console.log(element.id);
  websocket.send(element.id);
}



// new in v035. taken from RNT enhanced wifimgr.html
function myFunction() {
  // Get the checkbox
  var checkBox = document.getElementById("dhcp");


  // If the checkbox is checked
  if (checkBox.checked == true) {
	document.getElementById("ip").type = "text";
	document.getElementById("gateway").type = "text";
	document.getElementById("subnet").type = "text";

	document.getElementById("ip").value = "auto router will do this";
	document.getElementById("gateway").value = "auto router will do this";
	document.getElementById("subnet").value = "auto router will do this";

	document.getElementById("ip").disabled = true;
	document.getElementById("gateway").disabled = true;
	document.getElementById("subnet").disabled = true;

	document.getElementById("fixed").value = "Skip the next 3 lines";
	} 
  else {
	document.getElementById("ip").type = "text"; // would like to use number so that a number keyboard comes up on phone but that doe not allow multiple points  192.168 and then i cannot enter a point
	// type text and ip shows a keyboard on phone 
	document.getElementById("gateway").type = "text";
	document.getElementById("subnet").type = "text";

	document.getElementById("ip").disabled = false;
	document.getElementById("gateway").disabled = false;
	document.getElementById("subnet").disabled = false;

	document.getElementById("ip").value = "";
	document.getElementById("gateway").value = "";
	document.getElementById("subnet").value = "";

	document.getElementById("fixed").value = "Enter next 3 fields";
  }
}



